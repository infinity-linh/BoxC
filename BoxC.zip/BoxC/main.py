import chapter.main_window.main_page
# import login.login_page

if __name__ == "__main__":
    # app = login.login_page.App()
    app = chapter.main_window.main_page.App_main()
    app.mainloop()